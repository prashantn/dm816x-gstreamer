/* -*- Mode: C; tab-width: 4; indent-tabs-mode: t; c-basic-offset: 8 -*- */
/* =====================================================================
 *                Texas Instruments OMAP(TM) Platform Software
 *             Copyright (c) 2005 Texas Instruments, Incorporated
 *
 * Use of this software is controlled by the terms and conditions found
 * in the license agreement under which this software has been supplied.
 * ===================================================================== */

#ifndef __GST_NAL2BYTESTR_H__
#define __GST_NAL2BYTESTR_H__

#include <gst/gst.h>
#include <string.h>
#include <gst/base/gstadapter.h>

G_BEGIN_DECLS

/* #defines don't like whitespacey bits */
#define GST_TYPE_NAL2BYTESTR (gst_nal2bytestr_get_type())
#define GST_NAL2BYTESTR(obj) \
            (G_TYPE_CHECK_INSTANCE_CAST((obj),GST_TYPE_NAL2BYTESTR,GstNal2Bytestr))
#define GST_NAL2BYTESTR_CLASS(klass) \
            (G_TYPE_CHECK_CLASS_CAST((klass), \
             GST_TYPE_NAL2BYTESTR,GstNal2BytestrClass))
#define GST_IS_NAL2BYTESTR(obj) \
            (G_TYPE_CHECK_INSTANCE_TYPE((obj),GST_TYPE_NAL2BYTESTR))
#define GST_IS_NAL2BYTESTR_CLASS(klass) \
            (G_TYPE_CHECK_CLASS_TYPE((klass), GST_TYPE_NAL2BYTESTR))

/***************
** Structures **
****************/

typedef struct _GstNal2Bytestr      GstNal2Bytestr;
typedef struct _GstNal2BytestrClass GstNal2BytestrClass;

typedef struct _n2bDim           n2bDim, n2bCoord;
typedef struct _n2bResults       n2bResults;
typedef struct _n2bConfigParams  n2bConfigParams;
typedef struct _n2bComponent     n2bComponent;


/*************************************
** NAL2Bytestream Plugin Structures **
**************************************/

/*** Contains the definition for the GstNal2Bytestr element */
struct _GstNal2Bytestr
{
    GstElement     element;
    GstPad         *sinkpad, *srcpad;

    unsigned long  offset;
    gdouble        framerate;
    guint          iNALunit_header_size;
    n2bComponent   *pNal2BytestrComp;
    GstBuffer      *video_header;

    gboolean       NAL_format;
    gboolean       silent;
    gboolean       bParsed_Header;
    GstAdapter     *adapter;

    GstCaps *negotiated_caps;
};

/*** Defines GstNal2BytestrClass. */
struct _GstNal2BytestrClass
{
    GstElementClass parent_class;
};


/******************************
** GstNal2Bytestr Structures **
*******************************/

struct _n2bDim {
    gint32  x;
    gint32  y;
};

struct _n2bResults {
    guint32 myFrameNumber;
    n2bCoord myCoord;
    n2bCoord myOffset;
    guint32 myStabFlags;
};

struct _n2bConfigParams {
    n2bDim   myInFrame;
    n2bDim   myOutFrame;
};


struct _n2bComponent {
    n2bConfigParams  sNal2Bytestr_Params;
    guint32         nNal2Bytestr_Flags;
};



/***************
** Prototypes **
***************/
GType gst_nal2bytestr_get_type (void);



/*****************/
G_END_DECLS

#endif /* __GST_NAL2BYTESTR_H__ */
