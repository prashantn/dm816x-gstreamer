/* -*- Mode: C; tab-width: 8; indent-tabs-mode: t; c-basic-offset: 8 -*- */
/* =====================================================================
 *                Texas Instruments OMAP(TM) Platform Software
 *             Copyright (c) 2005 Texas Instruments, Incorporated
 *
 * Use of this software is controlled by the terms and conditions found
 * in the license agreement under which this software has been supplied.
 * ===================================================================== */



#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <gst/gst.h>

#include "gstnal2bytestream_h264.h"


/*********************
** Debugging Macros **
*********************/

/* Sets the GST debug category  */
GST_DEBUG_CATEGORY_STATIC (gst_nal2bytestr_debug);
#define GST_CAT_DEFAULT gst_nal2bytestr_debug


#define GST_ERROR_ALERT(ELEMENT, ARGS...) \
    GST_ELEMENT_ERROR(ELEMENT, STREAM, FORMAT, (ARGS), (NULL))

#define GST_NAL2BYTESTR_ENTER() GST_LOG(">>>> ENTERING")

#define GST_NAL2BYTESTR_EXIT() GST_LOG("<<<< EXITING")

#define GST_NAL2BYTESTR_EXIT_RET(ARGSTR,ARGS...) \
    GST_LOG("<<<< EXITING: ret=["ARGSTR"]",ARGS);


/* Filter signals and args */
enum
{
  /* FILL ME */
  LAST_SIGNAL
};

enum
{
  ARG_0,
  ARG_SILENT
};



/***************
** Prototypes **
***************/

static GstStaticPadTemplate sink_factory = GST_STATIC_PAD_TEMPLATE ("sink",
    GST_PAD_SINK,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS ("video/x-h264,"
        "framed = (boolean) false, "
        "width = (int)[16,8192], "
        "height = (int)[16,8192], " "framerate = (fraction) [1/1, 500/1];")
    );

static GstStaticPadTemplate src_factory = GST_STATIC_PAD_TEMPLATE ("src",
    GST_PAD_SRC,
    GST_PAD_ALWAYS,
    GST_STATIC_CAPS ("video/x-h264,"
        "framed = (boolean) true, "
        "width = (int)[16,8192], "
        "height = (int)[16,8192], " "framerate = (fraction) [1/1, 500/1];")
    );


GST_BOILERPLATE (GstNal2Bytestr, gst_nal2bytestr, GstElement, GST_TYPE_ELEMENT);

static void gst_nal2bytestr_base_init (gpointer gclass);
static void gst_nal2bytestr_class_init (GstNal2BytestrClass * klass);
static void gst_nal2bytestr_init (GstNal2Bytestr * filter,
    GstNal2BytestrClass * gclass);

static void gst_nal2bytestr_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec);
static void gst_nal2bytestr_get_property (GObject * object, guint prop_id,
    GValue * value, GParamSpec * pspec);
static gboolean gst_nal2bytestr_set_caps (GstPad * pad, GstCaps * caps);
static GstCaps *gst_nal2bytestr_get_caps (GstPad * pad);
static GstFlowReturn gst_nal2bytestr_chain (GstPad * pad, GstBuffer * buf);
static GstFlowReturn gst_nal2bytestr_pad_event (GstPad * pad, GstEvent * event);

static void gst_nal2bytestr_dispose (GObject * object);
static void gst_nal2bytestr_finalize (GstNal2Bytestr * filter);


static GstStateChangeReturn gst_nal2bytestr_state_change (GstElement * element,
    GstStateChange transition);



/*===========================================================================*/
/**
* gst_nal2bytestr_base_init()
* Initializes the GstNal2Bytestr class and child class properties.
*/
/*===========================================================================*/
static void
gst_nal2bytestr_base_init (gpointer gclass)
{

  GstElementClass *element_class = GST_ELEMENT_CLASS (gclass);

  GST_NAL2BYTESTR_ENTER ();

  gst_element_class_add_pad_template (element_class,
      gst_static_pad_template_get (&src_factory));
  gst_element_class_add_pad_template (element_class,
      gst_static_pad_template_get (&sink_factory));
  gst_element_class_set_details_simple (element_class,
      "H264 video frame converter",
      "Filter/Depayloader/Converter/Video",
      "Converts H264 frames from NAL format to Bytestream format",
      "Texas Instruments Inc.");

  GST_NAL2BYTESTR_EXIT ();
}


/*===========================================================================*/
/**
* gst_nal2bytestr_class_init()
* Initializes the GstNal2Bytestr class specifying signals, arguments and virtual
* functions while setting up global state.
*/
/*===========================================================================*/
static void
gst_nal2bytestr_class_init (GstNal2BytestrClass * klass)
{

  GObjectClass *gobject_class;
  GstElementClass *gstelement_class;

  gobject_class = (GObjectClass *) klass;
  gstelement_class = (GstElementClass *) klass;

  GST_NAL2BYTESTR_ENTER ();

  gobject_class->set_property =
      GST_DEBUG_FUNCPTR (gst_nal2bytestr_set_property);
  gobject_class->get_property =
      GST_DEBUG_FUNCPTR (gst_nal2bytestr_get_property);

  g_object_class_install_property (gobject_class,
      ARG_SILENT,
      g_param_spec_boolean ("silent",
          "Silent", "Produce verbose output ?", FALSE, G_PARAM_READWRITE));

  gstelement_class->change_state = gst_nal2bytestr_state_change;

  gobject_class->dispose = gst_nal2bytestr_dispose;
  gobject_class->finalize = (GObjectFinalizeFunc) gst_nal2bytestr_finalize;

  GST_NAL2BYTESTR_EXIT ();
}

/*===========================================================================*/
/**
* gst_nal2bytestr_init()
* initialize the new element
* instantiate pads and add them to element
* set functions
* initialize structure
*/
/*===========================================================================*/
static void
gst_nal2bytestr_init (GstNal2Bytestr * filter, GstNal2BytestrClass * gclass)
{

  GstElementClass *klass = GST_ELEMENT_GET_CLASS (filter);

  GST_NAL2BYTESTR_ENTER ();

  /* create the sink pad */
  filter->sinkpad =
      gst_pad_new_from_template (gst_element_class_get_pad_template (klass,
          "sink"), "sink");
  gst_pad_set_setcaps_function (filter->sinkpad,
      GST_DEBUG_FUNCPTR (gst_nal2bytestr_set_caps));

  /* create the src pad */
  filter->srcpad =
      gst_pad_new_from_template (gst_element_class_get_pad_template (klass,
          "src"), "src");
  gst_pad_set_getcaps_function (filter->srcpad,
      GST_DEBUG_FUNCPTR (gst_nal2bytestr_get_caps));

  /* add pads */
  gst_element_add_pad (GST_ELEMENT (filter), filter->sinkpad);
  gst_element_add_pad (GST_ELEMENT (filter), filter->srcpad);

  /* define the chain function */
  gst_pad_set_chain_function (filter->sinkpad,
      GST_DEBUG_FUNCPTR (gst_nal2bytestr_chain));
  /* define the event function */
  gst_pad_set_event_function (filter->sinkpad,
      GST_DEBUG_FUNCPTR (gst_nal2bytestr_pad_event));

  filter->silent = FALSE;
  filter->NAL_format = FALSE;

  /* Element properties initial values */
  //filter->offset = 0;
  //filter->framerate=0;
  filter->iNALunit_header_size = 4;
  filter->bParsed_Header = FALSE;

  filter->negotiated_caps = NULL;
  filter->adapter = gst_adapter_new ();

  GST_NAL2BYTESTR_EXIT ();
}


static void
gst_nal2bytestr_set_property (GObject * object, guint prop_id,
    const GValue * value, GParamSpec * pspec)
{
  GstNal2Bytestr *filter = GST_NAL2BYTESTR (object);

  switch (prop_id) {
    case ARG_SILENT:
      filter->silent = g_value_get_boolean (value);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}

static void
gst_nal2bytestr_get_property (GObject * object, guint prop_id, GValue * value,
    GParamSpec * pspec)
{
  GstNal2Bytestr *filter = GST_NAL2BYTESTR (object);

  switch (prop_id) {
    case ARG_SILENT:
      g_value_set_boolean (value, filter->silent);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
  }
}


/* GstElement vmethod implementations */

/*===========================================================================*/
/**
* gst_nal2bytestr_set_caps()
* Configure caps PATH and structure.
* this function handles the link with other elements
*/
/*===========================================================================*/
static gboolean
gst_nal2bytestr_set_caps (GstPad * pad, GstCaps * caps)
{
  GstNal2Bytestr *filter;
  GstStructure *structure;

  const gchar *mime;
  gboolean result = TRUE;

  GST_NAL2BYTESTR_ENTER ();

  filter = GST_NAL2BYTESTR (gst_pad_get_parent (pad));
  structure = gst_caps_get_structure (caps, 0);
  GST_DEBUG_OBJECT (filter, "caps=%" GST_PTR_FORMAT, caps);

  /* Verify if the input cap is Video */
  mime = gst_structure_get_name (structure);
  if (strcmp (mime, "video/x-h264") != 0) {
    GST_WARNING ("Wrong mimetype %s provided, only %s is supported",
        mime, "video/x-h264");
    result = FALSE;
  } else {
    g_return_val_if_fail (gst_caps_get_size (caps) == 1, FALSE);

#if defined(DEBUG)
    GST_DEBUG_OBJECT (filter, "set_caps (sink) = %" GST_PTR_FORMAT, caps);
#endif /* defined(DEBUG) */

    /* Verify input caps */
    {
      GstCaps *tmp_caps = gst_pad_get_allowed_caps (pad);
      if (tmp_caps) {
        GstStructure *tmp_structure;
        const GValue *value;

        tmp_caps = gst_caps_make_writable (tmp_caps);
        tmp_structure = gst_caps_get_structure (tmp_caps, 0);
        gst_structure_set (tmp_structure, "framed", G_TYPE_BOOLEAN, TRUE, NULL);

        filter->negotiated_caps = tmp_caps;

        /* Get Codec data header info */
        structure = gst_caps_get_structure (tmp_caps, 0);
        if ((value = gst_structure_get_value (structure, "codec_data"))) {
          filter->video_header = gst_value_get_buffer (value);

          /* strip out codec_data, to work around bug in codec */
          gst_structure_remove_field (structure, "codec_data");

          GST_DEBUG_OBJECT (filter, "removed codec_data");
        }

        GST_DEBUG_OBJECT (filter, "negotiated caps: %" GST_PTR_FORMAT,
            filter->negotiated_caps);

        /* Passing HERE the sink caps to the srcpad */
        /* update output caps */
        if (!gst_pad_set_caps (filter->srcpad, filter->negotiated_caps)) {
          result = FALSE;
          GST_INFO ("Caps negotiation failed");
        }
      }
    }
  }                             /* end else */

  GST_NAL2BYTESTR_EXIT ();
  return result;
}


static GstCaps *
gst_nal2bytestr_get_caps (GstPad * pad)
{
  GstNal2Bytestr *filter;

  GST_NAL2BYTESTR_ENTER ();

  filter = GST_NAL2BYTESTR (gst_pad_get_parent (pad));

  if (filter->negotiated_caps) {
    GST_DEBUG_OBJECT (filter, "caps already negotiated: %" GST_PTR_FORMAT,
        filter->negotiated_caps);
    return gst_caps_ref (filter->negotiated_caps);
  }

  return gst_caps_copy (gst_pad_get_pad_template_caps (pad));
}



/*===========================================================================*/
/**
* gst_nal2bytestr_codec_data_processing()
* Function to Parse codec-data header and replace NAL unit headers in 1st.
* buffer
*/
/*===========================================================================*/

static GstFlowReturn
gst_nal2bytestr_codec_data_processing (GstNal2Bytestr * filter,
    GstBuffer ** bufp)
{
  GstBuffer *buf = *bufp;
  gint index, profile, level, NALU_size_bytes;
  gint m_DecoderSpecificSize, numOfSPS;
  gint numOfPPS, pos, i;
  guint64 sps_len, pps_len;
  unsigned char *buff, *pSPS = pSPS, *pPPS = pPPS, *m_pDecoderSpecific;
  GstBuffer *new_buf, *temp_buffer;
  guint Header_size;


  if (GST_IS_BUFFER (filter->video_header)) {
    GST_DEBUG_OBJECT (filter, "Adding H.264 header info to buffer");

        /** We need to make this workaround for buffers
            after parsing the headers **/

    index = 0, profile = 0, level = 0, NALU_size_bytes = 0;
    m_DecoderSpecificSize = 0, numOfSPS = 0;
    numOfPPS = 0, pos = 0, i = 0;
    sps_len = 0, pps_len = 0;


    filter->bParsed_Header = TRUE;
    buff = GST_BUFFER_DATA (filter->video_header);

    /* verify header == 1 */
    if (buff[index] == 1)
        filter->NAL_format = TRUE;
    else {
        filter->NAL_format = FALSE;
        return GST_FLOW_OK;
    }

    index++;
    /* profile ID */
    profile = buff[index++];
    /* TODO: read compatible profiles */
    index++;
    /* level */
    level = buff[index++];
    GST_DEBUG_OBJECT (filter, "H.264 ProfileID=%d, Level=%d", profile, level);

    /* 6 bits reserved (111111) + 2 bits nal size length - 1 (11) */
    NALU_size_bytes = (buff[index++] & 0x03) + 1;
    GST_DEBUG_OBJECT (filter, "NALU size = %d", NALU_size_bytes);
    /* TODO: validate value == 1, 2, or 4 */

        /***********       Forcing NALU_size_bytes = 0 !!!!!     ***************/
    //NALU_size_bytes = 0;

    switch (NALU_size_bytes) {
      case 1:
        filter->iNALunit_header_size = 1;
        break;
      case 2:
        filter->iNALunit_header_size = 2;
        break;
      case 4:
        filter->iNALunit_header_size = 4;
        break;
      default:
        filter->iNALunit_header_size = 4;
        break;
    }

    Header_size = filter->iNALunit_header_size;
    GST_DEBUG_OBJECT (filter, "Header_size !!!! = %d", Header_size);
#if 0
    if (NALU_size_bytes) {
      return buf;
    }
#endif


    /* 3 bits reserved (111) + 5 bits number of SPS */
    numOfSPS = buff[index++] & 0x1f;
    GST_DEBUG_OBJECT (filter, "Number of SPS's = %d", numOfSPS);

    /* WORKAROUND: Make it look like MP4Box */
    /* Add NAL header size bytes to the data size */
    m_DecoderSpecificSize = Header_size;

    for (i = 0; i < numOfSPS; i++) {
      /* Remember first SPS NAL unit */
      if (i == 0)
        pSPS = buff + index;

      /* SPS length */
      sps_len = buff[index++] * 0x100;
      sps_len += buff[index++];
      GST_DEBUG_OBJECT (filter, "SPS #%d: sps_len=%llu", i, sps_len);
      m_DecoderSpecificSize += sps_len + Header_size;
      /* skip SPS content */
      index += sps_len;
    }

    /* number of PPS */
    numOfPPS = buff[index++];
    GST_DEBUG_OBJECT (filter, "Number of PPS's = %d", numOfPPS);

    for (i = 0; i < numOfPPS; i++) {
      /* Remember first PPS NAL unit */
      if (i == 0)
        pPPS = buff + index;

      /* PPS length */
      pps_len = buff[index++] * 0x100;
      pps_len += buff[index++];
      GST_DEBUG_OBJECT (filter, "PPS #%d: pps_len=%llu", i, pps_len);
      m_DecoderSpecificSize += pps_len + Header_size;
      /* skip PPS content */
      index += pps_len;
    }


    m_DecoderSpecificSize -= Header_size;
    GST_DEBUG_OBJECT (filter, "SPS's=%d, PPS's=%d, size=%d",
        numOfSPS, numOfPPS, m_DecoderSpecificSize);

    /* store SPS and PPS */
    /* FIXME: use gstbuffer; and validate */
    temp_buffer = gst_buffer_new_and_alloc (m_DecoderSpecificSize);
    m_pDecoderSpecific = GST_BUFFER_DATA (temp_buffer);
    GST_DEBUG_OBJECT (filter, "temp_buffer's size=%d",
        GST_BUFFER_SIZE (temp_buffer));

    index = 0;
    for (i = 0; i < numOfSPS; i++) {
      /* SPS length */
      sps_len = pSPS[index++] * 0x100;
      sps_len += pSPS[index++];
      switch (Header_size) {
        case 1:
          m_pDecoderSpecific[pos++] = sps_len & 0xFF;
          break;
        case 2:
          m_pDecoderSpecific[pos++] = (sps_len >> 8) & 0xFF;
          m_pDecoderSpecific[pos++] = (sps_len >> 0) & 0xFF;
          break;
        case 4:
        {
          if (NALU_size_bytes != 0) {
            m_pDecoderSpecific[pos++] = (sps_len >> 32) & 0xFF;
            m_pDecoderSpecific[pos++] = (sps_len >> 16) & 0xFF;
            m_pDecoderSpecific[pos++] = (sps_len >> 8) & 0xFF;
            m_pDecoderSpecific[pos++] = (sps_len >> 0) & 0xFF;
            GST_DEBUG_OBJECT (filter, "[%02x %02x]",
                m_pDecoderSpecific[pos - 2], m_pDecoderSpecific[pos - 1]);
          } else {
            /* WORKAROUND: Make it look like MP4Box */
            /* m_pDecoderSpecific[pos++] = (sps_len / 0x100) & 0xFF;
               m_pDecoderSpecific[pos++] = (sps_len % 0x100) & 0xFF; */
            m_pDecoderSpecific[pos++] = 0;
            m_pDecoderSpecific[pos++] = 0;
            m_pDecoderSpecific[pos++] = 0;
            m_pDecoderSpecific[pos++] = 1;
            GST_DEBUG_OBJECT (filter, "[%02x %02x]",
                m_pDecoderSpecific[pos - 2], m_pDecoderSpecific[pos - 1]);
          }
          break;
        }
      }
      GST_DEBUG_OBJECT (filter, "memcpy here. pos=%d, index=%d, sps_len=%llu",
          pos, index, sps_len);
      memcpy (m_pDecoderSpecific + pos, pSPS + index, sps_len);
      /* skip SPS content */
      index += sps_len;
      pos += sps_len;
    }

    index = 0;
    for (i = 0; i < numOfPPS; i++) {
      /* PPS length */
      pps_len = pPPS[index++] * 0x100;
      pps_len += pPPS[index++];
      switch (Header_size) {
        case 1:
          m_pDecoderSpecific[pos++] = pps_len & 0xFF;
          break;
        case 2:
          m_pDecoderSpecific[pos++] = (pps_len >> 8) & 0xFF;
          m_pDecoderSpecific[pos++] = (pps_len >> 0) & 0xFF;
          break;
        case 4:
        {
          if (NALU_size_bytes != 0) {
            m_pDecoderSpecific[pos++] = (pps_len >> 32) & 0xFF;
            m_pDecoderSpecific[pos++] = (pps_len >> 16) & 0xFF;
            m_pDecoderSpecific[pos++] = (pps_len >> 8) & 0xFF;
            m_pDecoderSpecific[pos++] = (pps_len >> 0) & 0xFF;
            GST_DEBUG_OBJECT (filter, "[%02x %02x]",
                m_pDecoderSpecific[pos - 2], m_pDecoderSpecific[pos - 1]);
          } else {
            /* WORKAROUND: Make it look like MP4Box */
            /* m_pDecoderSpecific[pos++] = (sps_len / 0x100) & 0xFF;
               m_pDecoderSpecific[pos++] = (sps_len % 0x100) & 0xFF; */
            m_pDecoderSpecific[pos++] = 0;
            m_pDecoderSpecific[pos++] = 0;
            m_pDecoderSpecific[pos++] = 0;
            m_pDecoderSpecific[pos++] = 1;
            GST_DEBUG_OBJECT (filter, "[%02x %02x]",
                m_pDecoderSpecific[pos - 2], m_pDecoderSpecific[pos - 1]);
          }
          break;
        }
      }
      GST_DEBUG_OBJECT (filter, "memcpy2 here. pos=%d, index=%d, pps_len=%llu",
          pos, index, pps_len);
      memcpy (m_pDecoderSpecific + pos, pPPS + index, pps_len);
      /* skip PPS content */
      index += pps_len;
      pos += pps_len;
    }

    /* WORKAROUND: Make it look like MP4Box */

    GST_DEBUG_OBJECT (filter, "WORKAROUND Make it look like MP4Box pos=%d, ",
        pos);

    //GST_BUFFER_DATA (buf) += 4;
    //GST_BUFFER_SIZE (buf) -= 4;
    GST_DEBUG ("GST_BUFFER_DATA: %p", GST_BUFFER_DATA (buf));
    GST_DEBUG ("GST_BUFFER_SIZE: %d", GST_BUFFER_SIZE (buf));

    new_buf = gst_buffer_merge (GST_BUFFER (temp_buffer), GST_BUFFER (buf));

    /* gst_buffer_merge() will end up putting temp_buffer's timestamp on
     * the new buffer, but actually we want buf's timestamp:
     */
    GST_BUFFER_TIMESTAMP (new_buf) = GST_BUFFER_TIMESTAMP (buf);

    gst_buffer_unref (temp_buffer);
    gst_buffer_unref (buf);

#if 0
    /* WORKAROUND: Make it look like MP4Box */
    GST_DEBUG_OBJECT (filter, "working around stuff 2");
    GST_BUFFER_DATA (new_buf)[545] = 0;
    GST_BUFFER_DATA (new_buf)[546] = 1;
#endif

    *bufp = new_buf;
  }

  return GST_FLOW_OK;
}





/*===========================================================================*/
/**
* gst_nal2bytestr_chain()
* Loop Function to Parse Header and Iterates in buffer.
*
* This function does the actual processing
*/
/*===========================================================================*/
static GstFlowReturn
gst_nal2bytestr_chain (GstPad * pad, GstBuffer * buf)
{
  GstNal2Bytestr *filter;
  GstBuffer *buf_nal2 = NULL;

  GstFlowReturn result = GST_FLOW_OK;

  GST_NAL2BYTESTR_ENTER ();

  filter = GST_NAL2BYTESTR (GST_OBJECT_PARENT (pad));

  if ((GST_BUFFER_TIMESTAMP (buf) == 0) || GST_BUFFER_IS_DISCONT (buf)) {
    result = gst_nal2bytestr_codec_data_processing (filter, &buf);
    if (result != GST_FLOW_OK) {
      return result;
    }
  }

  GST_INFO ("Input Buffer size=%d !!!", GST_BUFFER_SIZE (buf));

  /* If not NAL format simply push the bytestream buffer */
  if (filter->NAL_format == FALSE) {
    gst_buffer_set_caps (buf, GST_PAD_CAPS (filter->srcpad));
    result = gst_pad_push (filter->srcpad, buf);
  } else if (filter->iNALunit_header_size == 4) {
    guint8 *data;
    gint i, size;

    buf = gst_buffer_make_writable (buf);
    data = GST_BUFFER_DATA (buf);
    size = GST_BUFFER_SIZE (buf);

    size -= 3;                  /* too small for a NALU header */
    i = 0;

    while (i < size) {
      gint nal_size =
          (data[i + 0] << 24) |
          (data[i + 1] << 16) | (data[i + 2] << 8) | (data[i + 3] << 0);

      data[i + 0] = 0x00;
      data[i + 1] = 0x00;
      data[i + 2] = 0x00;
      data[i + 3] = 0x01;

      i += nal_size + filter->iNALunit_header_size;
    }

    gst_buffer_set_caps (buf, GST_PAD_CAPS (filter->srcpad));
    result = gst_pad_push (filter->srcpad, buf);
  } else if (filter->iNALunit_header_size == 2) {
    guint8 *data;
    gint index, buf_size, final_buf_size;
    GstBuffer *sub_buf, *temp_buf;

    buf_nal2 = gst_buffer_new_and_alloc (2);
    GST_BUFFER_DATA(buf_nal2)[0] = 0x00;
    GST_BUFFER_DATA(buf_nal2)[1] = 0x00;

    data = GST_BUFFER_DATA (buf);
    buf_size = GST_BUFFER_SIZE (buf);
    final_buf_size =  GST_BUFFER_SIZE (buf);
    buf_size -= 1;
    index = 0;

    while (index < buf_size)
    {
      gint nalu_size = (data[index+0] << 8) | data[index+1];
      data[index+0] = 0x00;
      data[index+1] = 0x01;

      sub_buf = gst_buffer_merge (buf_nal2,
          gst_buffer_create_sub (buf, index, nalu_size + 2));
      gst_adapter_push (filter->adapter, sub_buf);
      final_buf_size += 2;

      index += nalu_size + filter->iNALunit_header_size;
    }
    temp_buf = gst_adapter_take_buffer (filter->adapter, final_buf_size);
    GST_BUFFER_TIMESTAMP (temp_buf) = GST_BUFFER_TIMESTAMP (buf);
    gst_buffer_set_caps (temp_buf, GST_PAD_CAPS (filter->srcpad));
    result = gst_pad_push (filter->srcpad, temp_buf);
  } else {
    GST_WARNING_OBJECT (filter, "unsupported NALU header size: %d",
        filter->iNALunit_header_size);
  }

  GST_NAL2BYTESTR_EXIT ();
  return result;
}


/*===========================================================================*/
/**
* gst_nal2bytestr_state_change()
* Catches the change of states on the element.
*/
/*===========================================================================*/
static GstStateChangeReturn
gst_nal2bytestr_state_change (GstElement * element, GstStateChange transition)
{

  GstNal2Bytestr *filter = GST_NAL2BYTESTR (element);
  n2bComponent *n2bComp = NULL;

  GstStateChangeReturn result = GST_STATE_CHANGE_SUCCESS;

  GST_NAL2BYTESTR_ENTER ();

  switch (transition) {
    case GST_STATE_CHANGE_NULL_TO_READY:
      GST_DEBUG (" Change of state NULL_TO_READY ");
      break;
    case GST_STATE_CHANGE_READY_TO_PAUSED:
      GST_DEBUG (" Change of state READY_TO_PAUSED ");

      n2bComp = (n2bComponent *) g_malloc (sizeof (n2bComponent));
      if (n2bComp != NULL) {
        /*Initialize Element */
        n2bComp->sNal2Bytestr_Params.myInFrame.x = 0;
        n2bComp->sNal2Bytestr_Params.myInFrame.y = 0;
        n2bComp->sNal2Bytestr_Params.myOutFrame.x = 0;
        n2bComp->sNal2Bytestr_Params.myOutFrame.y = 0;

        /* Element pointers initial values */
        filter->pNal2BytestrComp = n2bComp;
      } else {
        GST_DEBUG (" n2bComp allocation failed !!!! ");
      }
      break;
    case GST_STATE_CHANGE_PAUSED_TO_PLAYING:
      GST_DEBUG (" Change of state PAUSED_TO_PLAYING ");
      break;
    default:
      GST_DEBUG (" Change of state (ignored) ");
      break;
  }

  result = GST_ELEMENT_CLASS (parent_class)->change_state (element, transition);

  switch (transition) {
    case GST_STATE_CHANGE_PLAYING_TO_PAUSED:
      GST_DEBUG (" Change of state PLAYING_TO_PAUSED ");
      break;
    case GST_STATE_CHANGE_PAUSED_TO_READY:
      GST_DEBUG (" Change of state PAUSED_TO_READY ");
      if (filter->pNal2BytestrComp != NULL) {
        g_free (filter->pNal2BytestrComp);
      }
      break;
    case GST_STATE_CHANGE_READY_TO_NULL:
      GST_DEBUG (" Change of state READY_TO_NULL ");
      break;
    default:
      GST_DEBUG (" Change of state (ignored) ");
      break;
  }

  GST_NAL2BYTESTR_EXIT ();
  return result;
}


static gboolean
gst_nal2bytestr_pad_event (GstPad * pad, GstEvent * event)
{
  GstNal2Bytestr *filter;
  gboolean ret = TRUE;

  GST_NAL2BYTESTR_ENTER ();

  filter = GST_NAL2BYTESTR (gst_pad_get_parent (pad));



  GST_INFO_OBJECT (filter, "begin: event=%s", GST_EVENT_TYPE_NAME (event));

  switch (GST_EVENT_TYPE (event)) {
    case GST_EVENT_EOS:
      ret = gst_pad_push_event (filter->srcpad, event);
      break;

    case GST_EVENT_FLUSH_START:
      gst_pad_push_event (filter->srcpad, event);
      ret = TRUE;
      break;

    case GST_EVENT_FLUSH_STOP:
      gst_pad_push_event (filter->srcpad, event);
      ret = TRUE;
      break;

    case GST_EVENT_NEWSEGMENT:
      ret = gst_pad_push_event (filter->srcpad, event);
      break;

    default:
      ret = gst_pad_push_event (filter->srcpad, event);
      break;
  }

  GST_NAL2BYTESTR_EXIT ();

  return ret;
}

static void
gst_nal2bytestr_dispose (GObject * object)
{
  GST_NAL2BYTESTR_ENTER ();

  G_OBJECT_CLASS (parent_class)->dispose (object);

  GST_NAL2BYTESTR_EXIT ();
}


static void
gst_nal2bytestr_finalize (GstNal2Bytestr * filter)
{
  GST_NAL2BYTESTR_ENTER ();
  if (filter->negotiated_caps) {
    gst_caps_unref (filter->negotiated_caps);
    filter->negotiated_caps = NULL;
  }
  gst_adapter_clear (filter->adapter);
  G_OBJECT_CLASS (parent_class)->finalize ((GObject *) (filter));
  GST_NAL2BYTESTR_EXIT ();
}


/*===========================================================================*/
/**
* plugin_init()
* Entry point to initialize the plugin as a shared object library.
* register the element factories and pad templates
* register the features
*
* This is the first function called in this file.
*/
/*===========================================================================*/
static gboolean
plugin_init (GstPlugin * plugin)
{
  gboolean ret = gst_element_register (plugin,
      "nal2bytestream_h264",
      GST_RANK_PRIMARY + 1,
      GST_TYPE_NAL2BYTESTR);

  /* initialize the debugger */
  GST_DEBUG_CATEGORY_INIT (gst_nal2bytestr_debug, "H264_nal2bytestream",
      0, "H264 Video frame converter");

  GST_NAL2BYTESTR_ENTER ();

  GST_INFO ("Built on " __DATE__ ":" __TIME__ "");

  GST_NAL2BYTESTR_EXIT_RET ("%s", (ret ? "true" : "false"));
  return ret;
}


/*===========================================================================*/
/**
* GST_PLUGIN_DEFINE()
* This is the structure for which gst-register looks.
*/
/*===========================================================================*/
GST_PLUGIN_DEFINE (GST_VERSION_MAJOR,
    GST_VERSION_MINOR,
    "nal2bytestream_h264",
    "H264_Video_frames_converter_plugin",
    plugin_init, VERSION, GST_LICENSE, GST_PACKAGE_NAME, GST_PACKAGE_ORIGIN)
