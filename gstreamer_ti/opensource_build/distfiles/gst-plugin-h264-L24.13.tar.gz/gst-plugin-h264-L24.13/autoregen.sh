#!/bin/sh
./autogen.sh --host=arm-none-linux-gnuenabi --disable-gtk-doc $@
