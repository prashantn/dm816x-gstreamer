#!/bin/sh
./autogen.sh --noconfigure $@
